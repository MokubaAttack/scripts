from setuptools import setup, find_packages

setup(
    name='mokucola',
    version='2.10.126',
    packages=find_packages(),
    include_package_data=True,
    author='mokuba_attack',
    description='This is a script that I use when I create images by diffusers.',
    url='https://github.com/MokubaAttack/scripts',
    license='BSD-3-Clause',
    classifiers=[
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3.12',
    ],
    install_requires=[
        "pyexiv2",
        "compel",
        "torchsde",
        "xformers @ https://download.pytorch.org/whl/cu126/xformers-0.0.35-py39-none-manylinux_2_28_x86_64.whl",
        "torch @ https://download.pytorch.org/whl/cu126/torch-2.10.0%2Bcu126-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=2a7a569206f07965eff69b28e147676540bb0ba6e1a39410802b6e4708cb8356",
        "torchvision @ https://download-r2.pytorch.org/whl/cu126/torchvision-0.25.0%2Bcu126-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=5831326b6710366b44c0124ce197b416b7b896efa27340c235081cc7f52870e5",
        "diffusers==0.37.0",
        "realesrgan",
        "tomesd",
    ],
)