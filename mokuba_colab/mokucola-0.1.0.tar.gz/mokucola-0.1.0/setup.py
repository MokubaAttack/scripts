from setuptools import setup, find_packages

setup(
    name='mokucola',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    author='mokuba_attack',
    description='This is a script that I use when I create images by diffusers.',
    url='https://github.com/MokubaAttack/scripts',
    license='BSD-3-Clause',
)