from setuptools import setup, find_packages

setup(
    name='mokucola',
    version='0.1.126',
    packages=find_packages(),
    include_package_data=True,
    author='mokuba_attack',
    description='This is a script that I use when I create images by diffusers.',
    url='https://github.com/MokubaAttack/scripts',
    license='BSD-3-Clause',
    classifiers=[
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3.12',
    ],
    install_requires=[
        "pyexiv2",
        "compel",
        "torchsde",
        "xformers @ https://download.pytorch.org/whl/cu126/xformers-0.0.33-cp39-abi3-manylinux_2_28_x86_64.whl#sha256=18f6250138898de298fa00acb338055e47bf852ee93a8757e0a8bf37b6508aec",
        "torch @ https://download.pytorch.org/whl/cu126/torch-2.9.0%2Bcu126-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=ea68e3146cd7d770c662f0120f18b8b4a6d96be4314e7196047b282887828cfb",
        "torchvision @ https://download.pytorch.org/whl/cu126/torchvision-0.24.0%2Bcu126-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=b7c53e2777afb0362cbd8c2b3b80272d512aae6156ff014a999ae5c5e601667d",
        "diffusers==0.34.0",
        "realesrgan",
    ],
)