import torch
from diffusers_anima import AnimaPipeline
import safetensors
import random
import os
from IPython.display import clear_output
import gc

from .meta import plus_meta
from .discord import to_discord
from .imgshow import imgshow
from .reset_func import reset_func

class mokuanipipe:
    def __init__(self):
        self.meta_dict={}
        self.pipe=None

    def mkpipe(
        self,
        base_safe="base.safetensors",
        loras=[],
        lora_weights=[],
        sample="",
        sgm="",
        dtype="f32",
        dev="cuda"
        ):
        if not(os.path.exists(base_safe)):
            print("the checkpoint file does not exist.")
            return -1
        try:
            f=safetensors.safe_open(base_safe, framework="pt", device="cpu")
            self.meta_dict["ckpt"]=f.metadata()["id"]
            del f
        except:
            self.meta_dict["ckpt"]=""
        self.meta_dict["ckpt_name"]=base_safe

        if dtype=="bf16":
            dtype=torch.bfloat16
        elif dtype=="f16":
            dtype=torch.float16
        else:
            dtype=torch.float32

        self.pipe = AnimaPipeline.from_single_file(base_safe,torch_dtype=dtype)
        self.pipe.to(dev)
        
        if sample in ["euler","euler_a_rf","euler_ancestral_rf"]:
            if not(sgm in ["beta","simple","normal"]):
                sgm="normal"
        else:
            sample=="flowmatch_euler"
            sgm="uniform"
        self.meta_dict["sa"]=sample+" "+sgm
        self.pipe.scheduler.set_sampling_config(sampler=sample,sigma_schedule=sgm)
        
        if loras!=[]:
            if len(loras)!=len(lora_weights):
                print("the number of lora does not equal the number of lora weight.")
                return -1
            i=0
            meta_id_list=[]
            meta_weight_list=[]
            for line in loras:
                if line.endswith(".safetensors"):
                    line=line.replace(".safetensors","")
                if os.path.exists(line+".safetensors"):
                    self.pipe.load_lora_weights(line+".safetensors",adapter_name="style"+str(i))
                    print(line+".safetensors is loaded.")
                    self.pipe.set_adapters("style"+str(i), adapter_weights=[lora_weights[i]])
                    self.pipe.fuse_lora()
                    self.pipe.unload_lora_weights()

                    list1=meta_id_list
                    list2=meta_weight_list
                    try:
                        f=safetensors.safe_open(line+".safetensors", framework="pt", device="cpu")
                        meta_id=f.metadata()["id"]
                        if "," in meta_id:
                            meta_id = meta_id.split(",")
                            for j in meta_id:
                                meta_id_list.append(int(j))
                        else:
                            meta_id_list.append(int(meta_id))
                        meta_weight=f.metadata()["weight"]
                        if "," in meta_weight:
                            meta_weight = meta_weight.split(",")
                            for j in meta_weight:
                                meta_weight_list.append(float(j)*lora_weights[i])
                        else:
                            meta_weight_list.append(float(meta_weight)*lora_weights[i])
                        del f,meta_id,meta_weight
                    except:
                        meta_id_list=list1
                        meta_weight_list=list2
                    del list1,list2
                else:
                    print(line+".safetensors does not exist.")
                    return -1
                i=i+1
            self.meta_dict["lora"]=str(meta_id_list)
            self.meta_dict["w"]=str(meta_weight_list)
            del meta_id_list,meta_weight_list
        else:
            self.meta_dict["lora"]="[]"
        self.meta_dict["loras"]=loras
        self.meta_dict["lora_weights"]=lora_weights
        gc.collect()
        return 1

    def text2image(self,prompt,n_prompt,gs,step,seed,x,y,out,out_folder,si,j_or_p,url):
        if self.pipe==None:
            print("You must make a pipeline.")
            return []

        self.meta_dict["pr"]=prompt
        self.meta_dict["ne"]=n_prompt
        memo="seed\n"
        for i in seed:
            memo=memo+str(i)+"\n"
        memo=memo+"ckpt : "+self.meta_dict["ckpt_name"]+"\n"
        memo=memo+"scheduler : "+self.meta_dict["sa"]+"\n"
        if self.meta_dict["loras"]!=[]:
            memo=memo+"lora : weight\n"
            for i in range(len(self.meta_dict["loras"])):
                memo=memo+self.meta_dict["loras"][i]+" : "+str(self.meta_dict["lora_weights"][i])+"\n"
        memo=memo+"num_inference_steps : "+str(step)+"\n"
        self.meta_dict["st"]=str(step)
        memo=memo+"guidance_scale : "+str(gs)+"\n"
        self.meta_dict["cf"]=str(gs)
        memo=memo+"prompt\n"+prompt+"\nnegative prompt\n"+n_prompt+"\n"

        self.pipe.vae.enable_tiling()
        
        if not(os.path.exists(out_folder)):
            os.makedirs(out_folder)
            
        j=0
        images=[]
        for i in seed:
            j=j+1
            clear_output(True)
            print(memo)
            if len(images)>0 and si:
                imgshow(imgs=images)
            image = self.pipe(
                prompt=prompt,
                negative_prompt=n_prompt,
                width=x,
                height=y,
                num_inference_steps=step,
                guidance_scale=gs,
                generator=torch.Generator(device="cpu").manual_seed(i),
            ).images[0]
            images.append(image)

            if out:
                self.meta_dict["se"]=str(i)
                if j_or_p=="j":
                    self.meta_dict["input"]=out_folder+"/"+str(j)+"_"+str(i)+".jpg"
                else:
                    self.meta_dict["input"]=out_folder+"/"+str(j)+"_"+str(i)+".png"
                plus_meta(self.meta_dict,image)
                if url!="":
                    to_discord(self.meta_dict["input"],url)
            del image
            torch.cuda.empty_cache()
        clear_output(True)
        print(memo)
        if si:
            imgshow(imgs=images)
        gc.collect()
        return images
