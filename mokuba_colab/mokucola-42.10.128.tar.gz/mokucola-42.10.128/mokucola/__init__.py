import os

path=__file__.replace("\\","/")
path=path.replace("mokucola/__init__.py","diffusers_anima")

if not(os.path.exists(path)):
    import subprocess
    import shutil
    import sys
    import importlib
    
    path=__file__.replace("\\","/")
    path=path.replace("__init__.py","diffusers_anima-1.0.0.tar.gz")
    shutil.copy(path,"diffusers_anima-1.0.0.tar.gz")
    cmd=["pip","install","diffusers_anima-1.0.0.tar.gz"]
    subprocess.run(cmd)
    os.remove("diffusers_anima-1.0.0.tar.gz")
    
    for k in list(sys.modules.keys()):
        if k.startswith("PIL"):
            try:
                importlib.reload(sys.modules[k])
            except:
                pass

try:
    from .workflow import (
        mokucola,
        mokuup,
        mokuani
    )
    from .dl import (
        dlc,
        dlk
    )
except:
    path=__file__.replace("\\","/")
    path=path.replace("mokucola/__init__.py","basicsr/data/degradations.py")
    f=open(path,"r")
    data=[]
    for line in f:
        if "from torchvision.transforms.functional_tensor import rgb_to_grayscale" in line:
            line=line.replace(
                "from torchvision.transforms.functional_tensor import rgb_to_grayscale",
                "from torchvision.transforms.functional import rgb_to_grayscale"
                )
        data+=[line]
    f.close()
    f=open(path,"w")
    for line in data:
        f.write(line)
    f.close()

    from .workflow import (
        mokucola,
        mokuup,
        mokuani
    )
    from .dl import (
        dlc,
        dlk
    )
