from .workflow import (
    mokucola,
    mokuup
)

import os
import torch

path1=os.path.dirname(torch.__file__).replace("/torch","/basicsr/data/degradations.py")
path2=os.path.dirname(mokucola.__file__)+"/degradations.py"
if os.path.exists(path2):
    os.rename(path1, path2)