import math
from diffusers.utils import make_image_grid
from PIL import Image
from IPython.display import display

def imgshow(imgs):
    d_imgs=imgs
    r=math.ceil(len(imgs)/2)
    if r*2!=len(imgs):
        d_imgs.append(Image.new('RGB', imgs[-1].size, (0, 0, 0)))
    display(make_image_grid(d_imgs, rows=r, cols=2))
    