from setuptools import setup, find_packages

setup(
    name='mokucola',
    version='0.1.1',
    packages=find_packages(),
    include_package_data=True,
    author='mokuba_attack',
    description='This is a script that I use when I create images by diffusers.',
    url='https://github.com/MokubaAttack/scripts',
    license='BSD-3-Clause',
    classifiers=[
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3.12',
    ],
    install_requires=[
        "pyexiv2",
        "compel",
        "torchsde",
        "xformers @ https://download.pytorch.org/whl/cu128/xformers-0.0.32.post2-cp39-abi3-manylinux_2_28_x86_64.whl#sha256=3d1fefe0006eb00a730b3b197ff41aab085f1209b50419baab6152445f09e508",
        "torch @ https://download.pytorch.org/whl/cu126/torch-2.8.0%2Bcu126-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=ce6e6a1f4803ad62d1fe51cec3fe5ca14bcd8bc7cace7b09d5590f8147fa16ad",
        "torchvision @ https://download.pytorch.org/whl/cu126/torchvision-0.23.0%2Bcu126-cp312-cp312-manylinux_2_28_x86_64.whl#sha256=7351ffe7a49fe8ef391c5eef3fc4f6c1e6f15d0e25e83b41e9a07a23c201c57f",
        "diffusers==0.34.0",
        "realesrgan",
    ],
)