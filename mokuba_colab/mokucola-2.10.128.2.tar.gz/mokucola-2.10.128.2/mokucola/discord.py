import os
import shutil
import requests
import json
import time
import discord

class sendpic(discord.Client):
    def setparams(self,ch,path):
        self.ch=ch
        self.path=path
    async def on_ready(self):
        c=self.get_channel(self.ch)
        if os.path.isdir(self.path):
            shutil.make_archive('archive_shutil', format='zip', root_dir=self.path)
            await c.send(file=discord.File('archive_shutil.zip'))
            os.remove('archive_shutil.zip')
        else:
            await c.send(content=os.path.basename(self.path),file=discord.File(self.path))
        await self.close()

async def to_discord(path,token,ch):
    intents = discord.Intents.default()
    intents.message_content = True
    client = sendpic(intents=intents)
    client.setparams(ch,path)
    await client.start(token)
